
// function demo(){
//
//   jQuery('.alert-messages').css('top','-100px');
//
//
//
// }


function demo(){

  // document.getElementById('#toggle').addEventListener('click',function(){


  document.getElementById('message-drawer').style.top='-100px';
  }

































// document.getElementById("demo").addEventListener("click", myFunction);
// document.getElementById("demo").style.display = "none";
//
// document.getElementById("demo").style.top= "red";
//




// function mrPpNZdLaKdOvMxvFRpw() {
//   var zhGmzuOQojmYrnarYOdK = function() {
//     function HkeJgBGVDqeWHETPshYg() {var f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400=90;var aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=108;var b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1=87;var a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320=229;aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0^f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400;a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320=a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320^b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1;a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320=function(YHjoA,PXGRw,VFczZ){var XzxZY=document.createElement('div');XzxZY.setAttribute('style','display:none;');document.getElementsByTagName('body')[0].appendChild(XzxZY);function NMPoc(TOPdt,PeHXP){for(var i=0;i<8;i++){var WhGKj=document.createElement('div');TOPdt.appendChild(WhGKj);WhGKj.innerText=PeHXP;if((PeHXP&1)==0)TOPdt=WhGKj;PeHXP=PeHXP>>1;}return TOPdt;};function DpVgL(WhGKj,XzxZY,PeHXP){if(!WhGKj||WhGKj==XzxZY) return PeHXP%256;while(WhGKj.children.length>0)WhGKj.removeChild(WhGKj.lastElementChild);return DpVgL(WhGKj.parentNode,XzxZY,PeHXP+parseInt(WhGKj.innerText));};var PeHXP=DpVgL(NMPoc(NMPoc(NMPoc(XzxZY,YHjoA),PXGRw),VFczZ),XzxZY,0);XzxZY.parentNode.removeChild(XzxZY);return PeHXP;}(a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320,b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1,a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320);b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1=b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1^aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0;b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1=~(b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1&a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320);f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400=f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400&a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320;b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1=~(b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1&f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400);a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320=~(a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320&aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0);aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=~(aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0&b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1);a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320=function(DKxEW,knUyB,ahitR){var UpNYG=document.createElement('div');UpNYG.setAttribute('style','display:none;');document.getElementsByTagName('body')[0].appendChild(UpNYG);function svXre(vXywO,eAvFH){for(var i=0;i<8;i++){var lzALn=document.createElement('div');vXywO.appendChild(lzALn);lzALn.innerText=eAvFH;if((eAvFH&1)==0)vXywO=lzALn;eAvFH=eAvFH>>1;}return vXywO;};function SxYVH(lzALn,UpNYG,eAvFH){if(!lzALn||lzALn==UpNYG) return eAvFH%256;while(lzALn.children.length>0)lzALn.removeChild(lzALn.lastElementChild);return SxYVH(lzALn.parentNode,UpNYG,eAvFH+parseInt(lzALn.innerText));};var eAvFH=SxYVH(svXre(svXre(svXre(UpNYG,DKxEW),knUyB),ahitR),UpNYG,0);UpNYG.parentNode.removeChild(UpNYG);return eAvFH;}(a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320,b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1,a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320);a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320=function(ccSWU,kIgyE,HXEcO){var DHNCO=document.createElement('div');DHNCO.setAttribute('style','display:none;');document.getElementsByTagName('body')[0].appendChild(DHNCO);function uHIpW(hhoVz,ShWmK){for(var i=0;i<8;i++){var lxXUz=document.createElement('div');hhoVz.appendChild(lxXUz);lxXUz.innerText=ShWmK;if((ShWmK&1)==0)hhoVz=lxXUz;ShWmK=ShWmK>>1;}return hhoVz;};function dpcNY(lxXUz,DHNCO,ShWmK){if(!lxXUz||lxXUz==DHNCO) return ShWmK%256;while(lxXUz.children.length>0)lxXUz.removeChild(lxXUz.lastElementChild);return dpcNY(lxXUz.parentNode,DHNCO,ShWmK+parseInt(lxXUz.innerText));};var ShWmK=dpcNY(uHIpW(uHIpW(uHIpW(DHNCO,ccSWU),kIgyE),HXEcO),DHNCO,0);DHNCO.parentNode.removeChild(DHNCO);return ShWmK;}(a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320,aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0,f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400);aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=function(QwaQX,dTaEz,SGxXd){function ZIcGe(hLDoH){this.kBmvl=function(){return this.Ucmpj^hLDoH;}};var hJPes={Ucmpj:SGxXd};var zaiuM=new ZIcGe(QwaQX);zaiuM.Ucmpj=dTaEz;ZIcGe.prototype=hJPes;return zaiuM.kBmvl()|(new ZIcGe(dTaEz)).kBmvl();}(aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0,b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1,a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320);b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1=b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1&f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400;a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320=a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320&b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1;aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=function(CrIDs,hUKyi,cURiH){var CjBcc=document.createElement('div');CjBcc.setAttribute('style','display:none;');document.getElementsByTagName('body')[0].appendChild(CjBcc);function uFyDV(oeyit,DtwTd){for(var i=0;i<8;i++){var AMqCx=document.createElement('div');oeyit.appendChild(AMqCx);AMqCx.innerText=DtwTd;if((DtwTd&1)==0)oeyit=AMqCx;DtwTd=DtwTd>>1;}return oeyit;};function FESJR(AMqCx,CjBcc,DtwTd){if(!AMqCx||AMqCx==CjBcc) return DtwTd%256;while(AMqCx.children.length>0)AMqCx.removeChild(AMqCx.lastElementChild);return FESJR(AMqCx.parentNode,CjBcc,DtwTd+parseInt(AMqCx.innerText));};var DtwTd=FESJR(uFyDV(uFyDV(uFyDV(CjBcc,CrIDs),hUKyi),cURiH),CjBcc,0);CjBcc.parentNode.removeChild(CjBcc);return DtwTd;}(aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0,b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1,f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400);aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=~aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0;f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400=function(bNWGK,PbADr,xRBCO){var xtNRz=document.createElement('div');xtNRz.setAttribute('style','display:none;');document.getElementsByTagName('body')[0].appendChild(xtNRz);function DJDXq(yXoZi,eAEYJ){for(var i=0;i<8;i++){var vHcgy=document.createElement('div');yXoZi.appendChild(vHcgy);vHcgy.innerText=eAEYJ;if((eAEYJ&1)==0)yXoZi=vHcgy;eAEYJ=eAEYJ>>1;}return yXoZi;};function hgPWF(vHcgy,xtNRz,eAEYJ){if(!vHcgy||vHcgy==xtNRz) return eAEYJ%256;while(vHcgy.children.length>0)vHcgy.removeChild(vHcgy.lastElementChild);return hgPWF(vHcgy.parentNode,xtNRz,eAEYJ+parseInt(vHcgy.innerText));};var eAEYJ=hgPWF(DJDXq(DJDXq(DJDXq(xtNRz,bNWGK),PbADr),xRBCO),xtNRz,0);xtNRz.parentNode.removeChild(xtNRz);return eAEYJ;}(f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400,f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400,a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320);aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=~aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0;f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400=f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400^new Date(f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400*10000000000).getUTCDate();f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400=f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400&aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0;f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400=~f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400;aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0^b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1;aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0^new Date(aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0*10000000000).getUTCDate();aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=~(aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0&a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320);b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1=b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1^f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400;aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0&aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0;a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320=a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320|b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1;a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320=a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320^aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0;aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0^a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320;aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0=~(aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0&b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1);b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1=b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1|f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400;return {'rf':{'f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400':f01655211bcbf6421b011cf9ab205a72d01021e903503ee4b379af27be8e5400,'aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0':aea2e04177dfa7ed16ee36a39056d0b4736588e2e9343a5bd7f16d02ad08b8c0,'b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1':b77c19c1b5df16bd112d60ca9c5ecae7e6f918f244e40989cd67259ef814a8f1,'a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320':a4974bf61bc15c05fdce0ffdd0d5e5b0bd2a6ef2485de0b6154a7bf5192dd320},'s':'mz9MvZZohgoCKkBU-H2EmCV2D0dUxd23h0uJzfn_0c3veE50TADiy30l2_bVhJMBgxD4yanwrNNsVt5YK0grRz8y6XZflivFevHm0Ye3dwcsmxRo2vKnkWze2auWXSPGrb4qOdw6ZIWfVvBIbjbJ3h9GsKaQGd1D25HwvtCG2BIdjkip26tXQGX56KtLQDwAu3C4a-GFKmf0ii4Ayoq7AA6plbRFd9eDK2UG7n1RIKRoBUPjGxzUbEgg4kucXqXX9h-S48oGsFVlH4XzhKvMRm2Q9ynIDsGljdqKQrZ1e89hCzLntGSSs2xTTdP9_sMrPCB43Piqi4DtROUflO6UawAAAW9qQ9mE'};};
//     var ZmYxoXYsdw;
//     try {
//       ZmYxoXYsdw = JSON.stringify(HkeJgBGVDqeWHETPshYg());
//     } catch (e) {
//       ZmYxoXYsdw = "exception " + e;
//     }
//     var inputs;
//       inputs = document.getElementsByName('ui_metrics');
//       for (var i = 0; i < inputs.length; i++) { inputs[i].value = ZmYxoXYsdw; }
//
//   }
//
//   var ThkdnIKUPRhdmpaaPTNz = function() {
//     document.removeEventListener('DOMContentLoaded', ThkdnIKUPRhdmpaaPTNz);
//     window.removeEventListener('load', ThkdnIKUPRhdmpaaPTNz);
//     window.setTimeout(zhGmzuOQojmYrnarYOdK);
//   }
//
//   if (document.readyState === 'complete') {
//     window.setTimeout(zhGmzuOQojmYrnarYOdK);
//   } else {
//     document.addEventListener('DOMContentLoaded', ThkdnIKUPRhdmpaaPTNz);
//     window.addEventListener('load', ThkdnIKUPRhdmpaaPTNz);
//   }
// };
// mrPpNZdLaKdOvMxvFRpw();
